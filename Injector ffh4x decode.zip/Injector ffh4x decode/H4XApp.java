package com.joel.ffh4xinject;
   /*Dec by CMODs Telegram @CoRingaModzYT*/

import android.app.Application;
import java.io.IOException;

public class H4XApp extends Application {
    public void onCreate() {
        super.onCreate();
        try {
            Runtime.getRuntime().exec("su");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
