package com.joel.ffh4xinject;
   /*Dec by CMODs Telegram @CoRingaModzYT*/

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Process;
import android.util.AttributeSet;
import android.view.View;
import android.view.WindowManager;

public class ESPView extends View implements Runnable {
    Paint b;
    Context baseContext;
    int c = 0;
    int d = 0;
    long e;
    Paint g;
    Paint h;
    float i;
    Paint j;
    Thread mThread = new Thread(this);

    public ESPView(Context context) {
        super(context, (AttributeSet) null, 0);
        this.baseContext = context;
        InitializePaints();
        setWillNotDraw(false);
        SetFPS(30);
        setLayerType(2, (Paint) null);
        setBackgroundColor(0);
        ClearCanvas(new Canvas(), 0);
        this.mThread.start();
    }

    private void ClearCanvas(Canvas canvas, int i2) {
        canvas.drawColor(i2, PorterDuff.Mode.CLEAR);
    }

    private void DrawCircle(Canvas canvas, int i2, int i3, int i4, int i5, float f2, float f3, float f4, float f5) {
        this.g.setColor(Color.rgb(i3, i4, i5));
        this.g.setAlpha(i2);
        this.g.setStrokeWidth(f2);
        canvas.drawCircle(f3, f4, f5, this.g);
    }

    private void DrawFilledCircle(Canvas canvas, int i2, int i3, int i4, int i5, float f2, float f3, float f4) {
        this.h.setColor(Color.rgb(i3, i4, i5));
        this.h.setAlpha(i2);
        canvas.drawCircle(f2, f3, f4, this.h);
    }

    private void DrawFilledRect(Canvas canvas, int i2, int i3, int i4, int i5, float f2, float f3, float f4, float f5) {
        this.h.setColor(Color.rgb(i3, i4, i5));
        int i6 = i2;
        this.h.setAlpha(i2);
        canvas.drawRect(f2, f3, f2 + f4, f3 + f5, this.h);
    }

    private void DrawLine(Canvas canvas, int i2, int i3, int i4, int i5, float f2, float f3, float f4, float f5, float f6) {
        this.g.setColor(Color.rgb(i3, i4, i5));
        int i6 = i2;
        this.g.setAlpha(i2);
        this.g.setStrokeWidth(f2);
        canvas.drawLine(f3, f4, f5, f6, this.g);
    }

    private void DrawRect(Canvas canvas, int i2, int i3, int i4, int i5, int i6, float f2, float f3, float f4, float f5) {
        this.g.setStrokeWidth((float) i6);
        this.g.setColor(Color.rgb(i3, i4, i5));
        int i7 = i2;
        this.g.setAlpha(i2);
        canvas.drawRect(f2, f3, f2 + f4, f3 + f5, this.g);
    }

    private void DrawRectEx(Canvas canvas, int i2, int i3, int i4, int i5, int i6, float f2, float f3, float f4, float f5) {
        this.g.setStrokeWidth((float) i6);
        this.g.setColor(Color.rgb(i3, i4, i5));
        int i7 = i2;
        this.g.setAlpha(i2);
        canvas.drawRect(f2, f3, f4, f5, this.g);
    }

    private void DrawText(Canvas canvas, int i2, int i3, int i4, int i5, String str, float f2, float f3, float size) {
        this.b.setColor(Color.rgb(i3, i4, i5));
        this.b.setAlpha(i2);
        this.b.setTextSize(size);
        canvas.drawText(str, f2, f3, this.b);
    }

    public void InitializePaints() {
        Paint paint = new Paint();
        this.g = paint;
        paint.setStyle(Paint.Style.STROKE);
        this.g.setAntiAlias(true);
        this.g.setColor(Color.rgb(0, 0, 0));
        Paint paint2 = new Paint();
        this.h = paint2;
        paint2.setStyle(Paint.Style.FILL);
        this.h.setAntiAlias(true);
        this.h.setColor(Color.rgb(0, 0, 0));
        Point c2 = getScreen();
        this.i = (float) (Math.sqrt((double) (c2.x * c2.y)) / 50.0d);
        Paint paint3 = new Paint();
        this.b = paint3;
        paint3.setAntiAlias(true);
        this.b.setTypeface(Typeface.MONOSPACE);
        this.b.setColor(Color.rgb(0, 0, 0));
        this.b.setTextAlign(Paint.Align.CENTER);
        this.b.setTextSize(this.i);
        this.b.setStyle(Paint.Style.FILL);
        Paint paint4 = new Paint();
        this.j = paint4;
        paint4.setAntiAlias(true);
        this.j.setColor(Color.rgb(0, 0, 0));
        this.j.setTextAlign(Paint.Align.CENTER);
        this.j.setTextSize(this.i);
        this.j.setStyle(Paint.Style.STROKE);
        this.j.setStrokeWidth(1.5f);
    }

    public void SetFPS(int i2) {
        this.e = (long) i2;
    }

    public long b() {
        return 1000 / this.e;
    }

    public Point getScreen() {
        Point point = new Point();
        WindowManager windowManager = (WindowManager) this.baseContext.getSystemService("window");
        if (Build.VERSION.SDK_INT >= 17) {
            windowManager.getDefaultDisplay().getRealSize(point);
        } else {
            windowManager.getDefaultDisplay().getSize(point);
        }
        if (point.y > point.x) {
            point.set(point.y, point.x);
        }
        return point;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (canvas != null && getVisibility() == 0 && (FloaterHS.ESPCheck() || FloaterHS.AIMCheck())) {
            SetFPS(FloaterHS.GetFPS());
            FloaterHS.DrawOn(this, canvas, FloaterHS.GetWIDTH(), FloaterHS.GetHEIGHT());
        }
        int i2 = this.c + 1;
        this.c = i2;
        if (((long) i2) > this.e) {
            this.c = 0;
        }
    }

    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
    }

    public void run() {
        Process.setThreadPriority(10);
        while (!this.mThread.isInterrupted()) {
            if (this.c != this.d && getVisibility() == 0) {
                this.d = this.c;
                postInvalidate();
            }
            try {
                Thread.sleep(b());
            } catch (InterruptedException e2) {
            }
        }
    }
}
