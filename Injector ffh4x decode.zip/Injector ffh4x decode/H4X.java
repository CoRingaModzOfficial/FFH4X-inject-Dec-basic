package com.joel.ffh4xinject;
   /*Dec by CMODs Telegram @CoRingaModzYT*/

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Html;
import android.util.Base64;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Random;
import java.util.UUID;

public class H4X {
    public static String AutoLogin = "";
    public static String AutoSave = "";
    public static String AutoSenha = "";
    public static String ImgLogin = "iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAIcUlEQVR42u3dsY7jRBwH4BO8AeIRjpLurqJf6XiAuycAXX8NlJRU1JzEE+wTnLj+CkRJGVHQI/EEJn8n44ydsWMntjeb/T5phE5LMs7szM8zYzv77BkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJzjb0W5wcKEAKgU5YaKABAAigBAACgCgEkBYP2oPMYiAGYMANCHNR7owxoP9GGNB/qwxgN9WOOBPqzxQB/WeKAPazzQhzUe6MMaD/RhjQf6sMYDfVjjgT6s8UAfvs3Gqzb/fFZ99er36vOvN4uUn397vWY9TV0v39yffE0cz/b/PWqTtz/9cPK1X37zR/XnX19MauuPn56fOvazfodjjrfw+5jcD+Ln288gAG4sPTu//Gq28uZdVb///YcX1fv7u7XqaT7XIQSOX/PVq2p7PFUMiPw1zWt//OX73td++U21HfxV/ZkmDN76+Ervtw2SulwQBPV7RygNte39h6oJjMJAzn4/x699+1NVi+MstJcAuIHp037AtH/xHz9Vvf79LwZQVd19Vx4kMcCibDvcQ9RT13X33a9TB38nBGYZ/PX7RX2l9wvbumb5He4+76a3feMzDcxc6gG+C5JDW+Wvvfw4BcDVBkB06lLHidI3LYxOsT2z1AM0f138O0SH7E43V6pnsK7de72e3B5RX7z+jLN1MVDSmfXNu59n+z1u36t43D0h2RuaEbghZhfxnoX2FQBPJQB6zpRp6prODs1ZbXfWLk+vV6pnsK7399Wp9WxvAIx47aQZVuwNXDatPp7K52fxfKYUbTVw7M3S5+WbXdvugveFTUABcDeq48UaMs5q0Xl6zmpr1XN1AdCdmscgm3H6X1hubLp7JWm2NLBHsWnCIv594QalAHhCAdC8Rzpb9wySteq5pgBoBlf+XvE+EWAjpuVn/T5LG3ppxtEZ2K1ZQyyP4t/LHJcAuOUAyNehD13PVQVAd/0fm2shAixbW8951s0uOx7XG8eT15uWJz/+svv5QqEkAJ5KAAx04rXquaoA6K7J09k/C7BmwO73NGa45p7fI9D+DPv1/dG6fz/4Z9rwEwBPIQC6Z7FrqedaAuBo+p8G2u6KwvOsrs2l+wyjwidK2hBMAREzg7ShOu+mnwC45QCoLxntbyyZtH5foZ6rCYDuZbmoPzv7b//7bSsg5g6APFzyDcG4n+FwM9LuJp8FNiQFwI0GwL5jb+rd+KkbeCvUczUBkA++dN0/m2YfbdbNHACtNX730mC+JJjxXgQBcOMB0FpbLhgAl9RzDQHQuhyX7lvonGlXCYCos3SHYLo0uOy6XwBcc+PVnfT0PfqlO/SqKQNzrXqa+uJSVumuuHif6PjR6Q+3zrZLnDH77qibEgD5+jteV7gOv0YAtDb7ShuC65z9BcC1Nd7gAzNjy4iBuVY9g7vfc5QJg7N19k9n2sKddWsFQLGutCEYs50Z70YUAI+g8epBEme52AAK0enGPqSTP5hzYmCuVc/RnkEaeA8VAOnsn3bY42pAYZNt1QAo7QWke/7tATyxANifieozVd8Zuu8hnfj/0/T5VACsVE+zbt89GLTb2S4FwNCTh7lSUI0cnK3pdhxHHE/fLbhrLQGGZkVR33J3/wmAq10CxNkyDdDLLs8ND8y16omzbHTkGID7aW3vJuBhpnBc4mdn7gHU9efX9OPs3/O04mqbgGk5kh7vLV0RSPcBLDDzEAA3dhXg6HUL3wcwpZ58jf0QVwGaaXb2qO/gM/gLB0DrCkDMRiIkSzOxdLw9MxUBIACGd9wXDoCp9TxEADRT/8M996frWTAAWg/5xHtGGOyn+cU7BHseFhIAAuDusdWzdgAUn/jrv7RZvtRZel0sfSZ+/+DRbCSCqPvsQekOwewR5YXuCxAAAuBGA6DvnoLzAyBfo/8x+QGktOk38JBP8SvT0r6Fx4EFgACY7wtBJi0Bkng2/7BTfzd2ULY2/QYe8mltWJa+PWj+B4MEgAC40RnAYTBdNgPIAyA25vJLdftvV5606Rdr+oGHfAa/PWj+ewMEgAAwAxi7Cdis07dr+TRYR2/67b4IdNS1/eIdgjH7mP8JQQEgAATA2ABIZ/RmcJ865u43+4w8g/d+e1D6YtAzNyEFgAAQABcGwOj3yW+BTpcgJwzc/abh0huCAuAaG6+e6pWmgenroWf6Xvi16jnZqffr6cmvjTX5iL8pMOkYu9fjo444vpEbcPXlx+5TljH443NeGgD790o/FwA3GAAD168PgzN2hS/cEFqrnqa+vr+SkwbIQNicfO0Mt8x2/obhcR0jntFvnfVLQTdy/X7y6cl4YGie/QABcE2Nlz20Mlyio17w9+vWqqezFh6ua/98wcCg3Aw+K3DGdxS21tyHv+XXX0fPgMtu4hkuIwbt4DMR3T+IeuKKggB4xHsAozvusl8auWo9KZzOfu1yt8zOVkcdajMf5wXvJwCuagYw9kzSPROc9+28i9dTWG6MK+VbZCe/dtKgnFJHJ6Qmf74oPYGa3QcwrewvTQqAJzQDAH1Y44E+rPFAH9Z4oA9rPNCHNR7owxoP9GGNB/qwxgN9WOOBPqzx0If1YY2HPqwPazz0YTQe+jAaD30YjYc+jMZDH0bjoQ+j8dCHNZ7GQx/WeBoPfVjjKcrjKwJgpgBQlMdeBIAAUAQAAkARAJwMAEW5tQIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACD/gf5F3Eluw0eOAAAAABJRU5ErkJggg==";
    public static SharedPreferences.Editor mEditor;
    public static SharedPreferences mPreferences;

    public static native String Login(String str, String str2, String str3, String str4, String str5, String str6, String str7, String str8, String str9, String str10, String str11, String str12, String str13, String str14, Context context);

    public static native String Toast();

    static {
        System.loadLibrary("FFH4X");
    }

    public static void Start(Context paramContext) {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(paramContext)) {
            paramContext.startActivity(new Intent("android.settings.action.MANAGE_OVERLAY_PERMISSION", Uri.parse("package:" + paramContext.getPackageName())));
            Process.killProcess(Process.myPid());
        } else if (paramContext.checkCallingOrSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0 && paramContext.checkCallingOrSelfPermission("android.permission.READ_PHONE_STATE") == 0) {
            SharedPreferences sharedPreferences = paramContext.getSharedPreferences("FFH4X", 0);
            mPreferences = sharedPreferences;
            mEditor = sharedPreferences.edit();
            String user = mPreferences.getString("ffh4x.login", "");
            String pass = mPreferences.getString("ffh4x.senha", "");
            String save = mPreferences.getString("ffh4x.save", "false");
            AutoLogin = user;
            AutoSenha = pass;
            AutoSave = save;
            AlertaGolpe(paramContext, getDeviceId(paramContext));
            Toast.makeText(paramContext, Html.fromHtml(Toast()), 1).show();
        } else {
            showInstalledAppDetails(paramContext, paramContext.getPackageName());
            Process.killProcess(Process.myPid());
        }
    }

    public static String getDeviceId(Context context) {
        if (Build.VERSION.SDK_INT >= 29) {
            return Settings.Secure.getString(context.getContentResolver(), "android_id");
        }
        TelephonyManager mTelephony = (TelephonyManager) context.getSystemService("phone");
        if (mTelephony.getDeviceId() != null) {
            return mTelephony.getDeviceId();
        }
        return Settings.Secure.getString(context.getContentResolver(), "android_id");
    }

    public static class Cancelar implements DialogInterface.OnClickListener {
        private final Context context;

        public Cancelar(Context context2) {
            this.context = context2;
        }

        public void onClick(DialogInterface dialog, int id) {
            ((Activity) this.context).finish();
        }
    }

    public static class NoKey implements DialogInterface.OnClickListener {
        private final Context context;

        public NoKey(Context context2) {
            this.context = context2;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            ((Activity) this.context).finish();
        }
    }

    public static void StartHS(Context paramContext, String user, String date, String vendedor, String p1, String p2) {
        Intent intent = new Intent(paramContext, FloaterHS.class);
        intent.putExtra("a", user);
        intent.putExtra("b", date);
        intent.putExtra("c", "HS");
        intent.putExtra("d", vendedor);
        paramContext.startService(intent);
    }

    public static void sdfsdfgrehwgfwefsd(Context paramContext, String newKey, String license, Toast makeText, AlertDialog.Builder builder2, String user, String date, String vendedor) {
        makeText.show();
        StartHS(paramContext, user, date, vendedor, newKey, license);
    }

    public static void vcxvxcvxcvs(Context paramContext, String ChaveLocal, String usuario, String CHAVE, String date, String vendedor) {
        Context context = paramContext;
        StringBuilder sb = new StringBuilder();
        sb.append("Bem Vindo : ");
        String str = usuario;
        sb.append(usuario);
        Toast makeText = Toast.makeText(paramContext, sb.toString(), 1);
        new AlertDialog.Builder(paramContext);
        AlertDialog.Builder builder2 = new AlertDialog.Builder(paramContext);
        builder2.setTitle("Usuario ou Senha Incorretos!!!");
        builder2.setCancelable(false);
        builder2.create();
        builder2.setPositiveButton("Sair", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Process.killProcess(Process.myPid());
            }
        });
        sdfsdfgrehwgfwefsd(paramContext, ChaveLocal, CHAVE, makeText, builder2, usuario, date, vendedor);
    }

    public static void exitGame(Context paramContext) {
        Process.killProcess(Process.myPid());
    }

    public static void invalidVPN(Context paramContext) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("Desative a VPN Para utilizar o MOD MENU !!! :)");
        AlertaUpdate.setPositiveButton("Sair", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Process.killProcess(Process.myPid());
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
    }

    public static void invalidVersion(Context paramContext) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("Versão Desabilitada");
        AlertaUpdate.setPositiveButton("Sair", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Process.killProcess(Process.myPid());
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
    }

    public static void invalidVMOSWait(Context paramContext) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("Aguarde alguns minutos antes de tentar novamente.");
        AlertaUpdate.setPositiveButton("Sair", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Process.killProcess(Process.myPid());
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
    }

    public static void invalidUser(Context paramContext) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("1 - Usuario não existe\n2 - Usuario ou Senha incorretos!\n3 - Não é o dono do Usuario");
        AlertaUpdate.setPositiveButton("Sair", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Process.killProcess(Process.myPid());
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
    }

    public static String randomString(int length) {
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((char) r.nextInt(65535));
        }
        return sb.toString();
    }

    public static void AlertaGolpe(final Context paramContext, final String device) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("1 º A equipe FFH4X utiliza apenas whatsapp para vendas!!\n2 º Os numeros de vendedores OFICIAIS estão na proxima mensagem!!\n3 º Caso tenha duvida sobre algum suposto revendedor entre em contato com a equipe!!");
        AlertaUpdate.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                H4X.AlertaVendedores(paramContext, device);
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
        ((TextView) dialog.findViewById(16908299)).setGravity(17);
    }

    public static void clickNumero(Context context, String txtNum) {
        String numero = txtNum.replace("+", "").replace(" ", "").replace("-", "");
        context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://wa.me/" + numero + "?text=Tenho interesse no modmenu FFH4X")));
    }

    public static void AlertaVendedores(final Context paramContext, final String device) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("VENDAS OFICIAIS\nBAZUKADK\n+55 11 93025-2572\nArcanjo\n+55 62 9316-4089\nWesley\n+55 11 97357-9459\nDUDU\n+55 21 96409-8506\nHG MODS\n+55 22 99930-4275\nJP MODS\n+55 37 98344567\nDANI GAMES\n+55 51 99482-9915\nArsad (India)\n+917074813693\nZidan (BD)\n+8801627299878\nJIBON GAMING (BD)\n+8801404345698\nSARIF GAMING (India)\n+919563014191\nAsTeam (India)\n+6287918066\nGod Zeus\n+55 14 99853-7283\nTIGRE MODS\n+55 11 94218-1296\nLEUNAM MODS\n+55 66 99923-2047\n");
        AlertaUpdate.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                H4X.CriarLogin(paramContext, device);
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
        ((TextView) dialog.findViewById(16908299)).setGravity(17);
    }

    private static String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return model;
        }
        return manufacturer + " " + model;
    }

    public static String getUniqueId(Context ctx) {
        return UUID.nameUUIDFromBytes((getDeviceName() + Settings.Secure.getString(ctx.getContentResolver(), "android_id") + Build.HARDWARE).replace(" ", "").getBytes()).toString().replace("-", "");
    }


    public static boolean isNetworkAvailable(Context context) {
        return ((ConnectivityManager) context.getSystemService("connectivity")).getActiveNetworkInfo() != null;
    }

    public static void AvisoInternet(Context paramContext) {
        AlertDialog.Builder AlertaUpdate = new AlertDialog.Builder(paramContext);
        AlertaUpdate.setTitle("Aviso");
        AlertaUpdate.setCancelable(false);
        AlertaUpdate.setMessage("Verifique a conexão com a internet :(");
        AlertaUpdate.setPositiveButton("Sair", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                Process.killProcess(Process.myPid());
            }
        });
        AlertDialog dialog = AlertaUpdate.create();
        dialog.getWindow().setType(getLayoutType());
        dialog.show();
    }

    private static int getLayoutType() {
        if (Build.VERSION.SDK_INT >= 26) {
            return 2038;
        }
        return 2002;
    }

    public static void CriarLogin(Context paramContext, String device) {
        boolean z;
        Context context = paramContext;
        final String deviceID = device;
        final Context paramContextN = paramContext;
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        float scale = paramContext.getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(context);
        ViewGroup.LayoutParams root_LayoutParams = new ViewGroup.LayoutParams(-2, -2);
        root.setOrientation(1);
        root.setLayoutParams(root_LayoutParams);
        ImageView imageView = new ImageView(context);
        LinearLayout.LayoutParams imageView_LayoutParams = new LinearLayout.LayoutParams(-2, -2);
        imageView_LayoutParams.width = -1;
        imageView_LayoutParams.height = (int) ((66.0f * scale) + 0.5f);
        imageView.setBackgroundColor(Color.parseColor("#ff000000"));
        CharSequence titulo = new String("FFH4X");
        imageView.setContentDescription(titulo);
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        byte[] imageBytes = Base64.decode(ImgLogin, 0);
        Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
        imageView.setImageBitmap(decodedImage);
        root.addView(imageView);
        imageView.setLayoutParams(imageView_LayoutParams);
        EditText login = new EditText(context);
        LinearLayout.LayoutParams login_LayoutParams = new LinearLayout.LayoutParams(-2, -2);
        login_LayoutParams.width = -1;
        login_LayoutParams.leftMargin = (int) ((scale * 4.0f) + 0.5f);
        login_LayoutParams.topMargin = (int) ((scale * 16.0f) + 0.5f);
        login_LayoutParams.rightMargin = (int) ((scale * 4.0f) + 0.5f);
        login_LayoutParams.bottomMargin = (int) ((scale * 4.0f) + 0.5f);
        Bitmap decodedImage2 = decodedImage;
        String str = new String("Login");
        imageView.setContentDescription(titulo);
        login.setHint(str);
        login.setRawInputType(1);
        login.setTextColor(Color.parseColor("#ff000000"));
        String str2 = str;
        login.setHintTextColor(Color.parseColor("#151515"));
        root.addView(login);
        login.setLayoutParams(login_LayoutParams);
        EditText senha = new EditText(context);
        byte[] imageBytes2 = imageBytes;
        ViewGroup.LayoutParams layoutParams = root_LayoutParams;
        LinearLayout.LayoutParams senha_LayoutParams = new LinearLayout.LayoutParams(-2, -2);
        senha_LayoutParams.width = -1;
        senha_LayoutParams.leftMargin = (int) ((scale * 4.0f) + 0.5f);
        senha_LayoutParams.topMargin = (int) ((scale * 4.0f) + 0.5f);
        senha_LayoutParams.rightMargin = (int) ((4.0f * scale) + 0.5f);
        senha_LayoutParams.bottomMargin = (int) ((16.0f * scale) + 0.5f);
        float f = scale;
        senha.setHint(new String("Senha"));
        senha.setInputType(129);
        senha.setTextColor(Color.parseColor("#ff000000"));
        senha.setHintTextColor(Color.parseColor("#151515"));
        root.addView(senha);
        senha.setLayoutParams(senha_LayoutParams);
        CheckBox checkBox = new CheckBox(context);
        LinearLayout.LayoutParams checkBox_LayoutParams = new LinearLayout.LayoutParams(-2, -2);
        checkBox_LayoutParams.width = -1;
        checkBox.setText("Salvar Login e senha");
        checkBox.setTextColor(Color.parseColor("#313131"));
        root.addView(checkBox);
        checkBox.setLayoutParams(checkBox_LayoutParams);
        login.setText(AutoLogin);
        senha.setText(AutoSenha);
        EditText login2 = login;
        if (AutoSave.equals("true")) {
            checkBox.setChecked(true);
            z = false;
        } else {
            z = false;
            checkBox.setChecked(false);
        }
        builder.setCancelable(z);
        builder.setView(root);
        builder.setNegativeButton("Cancelar", new Cancelar(context));
        AnonymousClass9 r7 = r0;
        final EditText editText = login2;
        LinearLayout.LayoutParams layoutParams2 = checkBox_LayoutParams;
        final EditText editText2 = senha;
        EditText editText3 = senha;
        Bitmap bitmap = decodedImage2;
        String str3 = str2;
        final CheckBox checkBox2 = checkBox;
        CheckBox checkBox3 = checkBox;
        byte[] bArr = imageBytes2;
        final Context context2 = paramContext;
        AnonymousClass9 r0 = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                String user = editText.getText().toString();
                String password = editText2.getText().toString();
                if (checkBox2.isChecked()) {
                    H4X.mEditor.putString("ffh4x.login", user);
                    H4X.mEditor.commit();
                    H4X.mEditor.putString("ffh4x.senha", password);
                    H4X.mEditor.commit();
                    H4X.mEditor.putString("ffh4x.save", "true");
                    H4X.mEditor.commit();
                } else {
                    H4X.mEditor.putString("ffh4x.login", "");
                    H4X.mEditor.commit();
                    H4X.mEditor.putString("ffh4x.senha", "");
                    H4X.mEditor.commit();
                    H4X.mEditor.putString("ffh4x.save", "false");
                    H4X.mEditor.commit();
                }
                if (user.isEmpty() && password.isEmpty()) {
                    Toast.makeText(paramContextN, "Todos os Campos devem ser prenchidos!!", 1).show();
                    Process.killProcess(Process.myPid());
                    String str = password;
                } else if (H4X.isNetworkAvailable(context2)) {
                    String str2 = password;
                    String DadosLogin = H4X.Login(user, password, deviceID, Build.MODEL, Build.SERIAL, Build.FINGERPRINT, Build.BOARD, Build.HARDWARE, Build.DEVICE, Build.BRAND, Build.MANUFACTURER, Build.PRODUCT, Build.BOOTLOADER, H4X.getUniqueId(context2), context2);
                    if (DadosLogin.isEmpty()) {
                        Toast.makeText(paramContextN, "Falhou em obter os dados de login!!", 1).show();
                        Process.killProcess(Process.myPid());
                    } else if (DadosLogin.equals("INVALIDO")) {
                        H4X.invalidUser(context2);
                    } else if (DadosLogin.equals("VERSAO")) {
                        H4X.invalidVersion(context2);
                    } else if (DadosLogin.equals("AGUARDE")) {
                        H4X.invalidVMOSWait(context2);
                    } else if (DadosLogin.equals("VPN")) {
                        H4X.invalidVPN(context2);
                    } else {
                        JsonObject params = new JsonParser().parse(DadosLogin).getAsJsonObject();
                        if (!params.isJsonNull()) {
                            String usuario = params.get("USUARIO").getAsString();
                            String data = params.get("DATA").getAsString();
                            String vendedor = params.get("VENDEDOR").getAsString();
                            if (!usuario.equals(user)) {
                                Process.killProcess(Process.myPid());
                            }
                            H4X.vcxvxcvxcvs(paramContextN, "", usuario, "", data, vendedor);
                            return;
                        }
                        H4X.invalidUser(paramContextN);
                    }
                } else {
                    H4X.AvisoInternet(paramContextN);
                }
            }
        };
        builder.setPositiveButton("Acessar", r7);
        AlertDialog alert = builder.create();
        alert.getWindow().setBackgroundDrawable(new ColorDrawable(-1));
        alert.getWindow().setType(getLayoutType());
        alert.show();
    }

    private static void showInstalledAppDetails(Context context, String packageName) {
        try {
            Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.parse("package:" + packageName));
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            context.startActivity(new Intent("android.settings.MANAGE_APPLICATIONS_SETTINGS"));
        }
    }
}
