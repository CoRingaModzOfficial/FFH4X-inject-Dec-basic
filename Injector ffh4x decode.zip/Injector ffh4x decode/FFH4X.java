package com.joel.ffh4xinject;
   /*Dec by CMODs Telegram @CoRingaModzYT*/

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import eu.chainfire.libsuperuser.Shell;
import java.util.Random;

public class FFH4X extends Activity {
    Button btnLogin;

    public static native void setDeviceInfo(Context context);

    static {
        System.loadLibrary("FFH4X");
    }

    public void showNoRootMessage() {
        new AlertDialog.Builder(this).setMessage("Não foi possível obter acesso root").setNegativeButton(17039370, (DialogInterface.OnClickListener) null).show();
    }

    public static String randomString(int length) {
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((char) r.nextInt(65535));
        }
        return sb.toString();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        try {
            Shell.Pool.SU.get(new Shell.OnShellOpenResultListener() {
                public void onOpenResult(boolean success, int reason) {
                    if (!success) {
                        FFH4X.this.showNoRootMessage();
                    }
                }
            });
        } catch (Shell.ShellDiedException e) {
            showNoRootMessage();
        }
        setDeviceInfo(this);
        Button button = (Button) findViewById(R.id.login);
        this.btnLogin = button;
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                H4X.Start(this);
            }
        });
    }
}
